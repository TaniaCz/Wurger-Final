package com.app.proyecto.Repository;

import com.app.proyecto.Entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {

    // ← SOLO ESTE MÉTODO (borra el otro)
    Optional<Role> findByName(String name);
}