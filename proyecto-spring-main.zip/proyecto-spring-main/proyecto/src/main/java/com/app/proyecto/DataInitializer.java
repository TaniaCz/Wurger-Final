package com.app.proyecto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        System.out.println("\n");
        System.out.println("======================================");
        System.out.println("USUARIO ADMIN POR DEFECTO:");
        System.out.println("Usuario: admin");
        System.out.println("Contraseña: 123456");
        System.out.println("======================================");
        System.out.println("Ve a la base de datos y crea manualmente:");
        System.out.println("INSERT INTO role (nombre) VALUES ('ADMIN'), ('USER');");
        System.out.println("INSERT INTO usuario (username,password,nombre,email,telefono,enabled) VALUES ('admin','" + passwordEncoder.encode("123456") + "','Admin','admin@demo.com','999999999',true);");
        System.out.println("Luego asigna los roles en la tabla usuario_roles");
        System.out.println("\n");
    }
}