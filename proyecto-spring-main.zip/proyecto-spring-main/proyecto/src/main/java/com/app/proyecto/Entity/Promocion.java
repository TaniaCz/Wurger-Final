package com.app.proyecto.Entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "promocion")
public class Promocion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_promocion")
    private Long idPromocion;

    private String nombre;
    private LocalDate inicio;
    private LocalDate fin;
    private Integer cantidad_usos = 0;

    @Enumerated(EnumType.STRING)
    private Estado estado = Estado.Activa;

    private String descripcion;

    @Column(name = "id_producto")
    private Long idProducto;

    public enum Estado {
        Activa, Inactiva
    }

    // getters y setters
    public Long getIdPromocion() { return idPromocion; }
    public void setIdPromocion(Long idPromocion) { this.idPromocion = idPromocion; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public LocalDate getInicio() { return inicio; }
    public void setInicio(LocalDate inicio) { this.inicio = inicio; }
    public LocalDate getFin() { return fin; }
    public void setFin(LocalDate fin) { this.fin = fin; }
    public Integer getCantidadUsos() { return cantidad_usos; }
    public void setCantidadUsos(Integer cantidad_usos) { this.cantidad_usos = cantidad_usos; }
    public Estado getEstado() { return estado; }
    public void setEstado(Estado estado) { this.estado = estado; }
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
    public Long getIdProducto() { return idProducto; }
    public void setIdProducto(Long idProducto) { this.idProducto = idProducto; }
}