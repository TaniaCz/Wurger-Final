package com.app.proyecto.Controller;

import com.app.proyecto.Entity.Role;
import com.app.proyecto.Entity.User;
import com.app.proyecto.Repository.RoleRepository;
import com.app.proyecto.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired private UserRepository userRepository;
    @Autowired private RoleRepository roleRepository;
    //@Autowired private PasswordEncoder passwordEncoder;

    record RegisterRequest(String username, String password, String nombre, String email) {}
    record LoginRequest(String username, String password) {}

    @PostMapping("/registro")
    public ResponseEntity<?> registro(@RequestBody RegisterRequest request) {

        if (userRepository.existsByUsername(request.username())) {
            return ResponseEntity.badRequest().body("El usuario ya existe");
        }

        // AHORA SÍ FUNCIONA 100%
        Role roleUser = roleRepository.findByName("ROLE_USER")
                .orElseGet(() -> {
                    Role nuevo = new Role();
                    nuevo.setName("ROLE_USER");
                    return roleRepository.save(nuevo);
                });

        User user = new User();
        user.setUsername(request.username());
        user.setPassword(request.password());  
        user.setNombre(request.nombre() != null ? request.nombre() : "");
        user.setEmail(request.email() != null ? request.email() : "");
        user.setRoles(new HashSet<>());
        user.addRole(roleUser);

        userRepository.save(user);

        return ResponseEntity.ok("Usuario registrado con éxito");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        return ResponseEntity.ok("Login funciona");
    }
}