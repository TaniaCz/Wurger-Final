-- Usuarios de prueba (no dan error si ya existen)
INSERT IGNORE INTO usuarios (nombre, email, telefono) 
VALUES ('Carlos Ramírez', 'carlos@gmail.com', '3001234567');

INSERT IGNORE INTO usuarios (nombre, email, telefono) 
VALUES ('Ana Gómez', 'ana@gmail.com', '3109876543');

INSERT IGNORE INTO usuarios (nombre, email, telefono) 
VALUES ('Luis Martínez', 'luis@gmail.com', NULL);

INSERT IGNORE INTO usuarios (nombre, email, telefono) 
VALUES ('María López', 'maria@gmail.com', '3154445566');