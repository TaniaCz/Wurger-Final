// admin-dashboard-script.js
const API_BASE = 'http://localhost:8080/api';
const token = localStorage.getItem('token');
const rol = localStorage.getItem('rol');

// === PROTECCIÓN: SOLO ADMINISTRADORES ===
if (!token || rol !== 'Administrador') {
  alert('Acceso restringido. Solo administradores.');
  window.location.href = 'index.html';
}

// Cerrar sesión
function logout() {
  localStorage.clear();
  window.location.href = 'index.html';
}

// Cargar datos del panel admin
async function cargarAdminDashboard() {
  try {
    const res = await fetch(`${API_BASE}/admin/stats`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });

    if (!res.ok) throw new Error('Error del servidor');

    const data = await res.json();

    // Estadísticas principales
    document.getElementById('ingresosHoy').textContent = `$${data.ingresosHoy?.toLocaleString() || 0}`;
    document.getElementById('vsAyer').textContent = data.vsAyer || '';
    document.getElementById('pedidosHoy').textContent = data.pedidosHoy || 0;
    document.getElementById('totalUsuarios').textContent = data.totalUsuarios || 0;
    document.getElementById('nuevosHoy').textContent = data.nuevosHoy ? `+${data.nuevosHoy} hoy` : '';
    document.getElementById('stockBajo').textContent = data.stockBajo || 0;

    // Actividad reciente
    const actividadDiv = document.getElementById('actividadReciente');
    actividadDiv.innerHTML = '';
    (data.actividadReciente || []).forEach(act => {
      actividadDiv.innerHTML += `
        <div class="activity-item">
          <strong>${act.accion}</strong><br>
          <small class="text-muted">${act.usuario} • ${new Date(act.fecha).toLocaleString()}</small>
        </div>`;
    });

    // Gráfico semanal
    const ctx = document.getElementById('weeklyChart').getContext('2d');
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'],
        datasets: [{
          label: 'Ventas ($)',
          data: data.ventasSemana || [4200, 5800, 5100, 7200, 8900, 12500, 9800],
          borderColor: '#ff6b6b',
          backgroundColor: 'rgba(255,107,107,0.2)',
          tension: 0.4,
          fill: true
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true } }
      }
    });

  } catch (err) {
    console.error('Error admin dashboard:', err);
  }
}

// Cargar al iniciar
document.addEventListener('DOMContentLoaded', cargarAdminDashboard);