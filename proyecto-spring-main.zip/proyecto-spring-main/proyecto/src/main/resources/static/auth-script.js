const API = 'http://localhost:8080/api/usuarios';

// Mostrar formularios
function mostrarRegistro() {
  document.getElementById('loginForm').style.display = 'none';
  document.getElementById('registroForm').style.display = 'block';
}
function mostrarLogin() {
  document.getElementById('loginForm').style.display = 'block';
  document.getElementById('registroForm').style.display = 'none';
}

// Validación nativa de Bootstrap
(function () {
  'use strict'
  var forms = document.querySelectorAll('form[novalidate]')
  Array.prototype.slice.call(forms).forEach(function (form) {
    form.addEventListener('submit', function (event) {
      if (!form.checkValidity()) {
        event.preventDefault()
        event.stopPropagation()
      }
      form.classList.add('was-validated')
    }, false)
  })
})();

// ========================
// OJOS PARA MOSTRAR/OCULTAR CONTRASEÑA
// ========================
function setupPasswordToggle(inputId, toggleId) {
  const input = document.getElementById(inputId);
  const toggle = document.getElementById(toggleId);

  toggle.addEventListener('click', () => {
    const tipo = input.getAttribute('type') === 'password' ? 'text' : 'password';
    input.setAttribute('type', tipo);
    toggle.classList.toggle('bi-eye');
    toggle.classList.toggle('bi-eye-slash');
  });
}

// Activar todos los ojos
setupPasswordToggle('loginPassword', 'toggleLoginPassword');
setupPasswordToggle('regPassword', 'toggleRegPassword');
setupPasswordToggle('regPassword2', 'toggleRegPassword2');

// ========================
// VALIDACIÓN DE FUERZA DE CONTRASEÑA
// ========================
const passwordInput = document.getElementById('regPassword');
const strengthBar = document.getElementById('passwordStrength');
const strengthText = document.getElementById('passwordStrengthText');

function validarFuerzaPassword(password) {
  const criterios = [
    { regex: /.{8,}/, nombre: '8+ caracteres' },
    { regex: /[A-Z]/, nombre: 'mayúscula' },
    { regex: /[a-z]/, nombre: 'minúscula' },
    { regex: /[0-9]/, nombre: 'número' },
    { regex: /[^A-Za-z0-9]/, nombre: 'símbolo' }
  ];

  let cumplidos = 0;
  const faltantes = [];

  criterios.forEach(c => {
    if (c.regex.test(password)) cumplidos++;
    else faltantes.push(c.nombre);
  });

  const porcentaje = cumplidos * 20;

  strengthBar.style.width = porcentaje + '%';
  strengthBar.classList.remove('bg-danger', 'bg-warning', 'bg-success');

  if (porcentaje === 0) {
    strengthText.textContent = 'Escribe una contraseña';
    strengthText.className = 'text-muted small';
  } else if (porcentaje < 60) {
    strengthBar.classList.add('bg-danger');
    strengthText.textContent = 'Débil – Falta: ' + faltantes.slice(0, 3).join(', ');
    strengthText.className = 'text-danger small';
  } else if (porcentaje < 100) {
    strengthBar.classList.add('bg-warning');
    strengthText.textContent = 'Aceptable';
    strengthText.className = 'text-warning small';
  } else {
    strengthBar.classList.add('bg-success');
    strengthText.textContent = '¡Contraseña fuerte!';
    strengthText.className = 'text-success small';
  }

  return porcentaje === 100;
}

passwordInput.addEventListener('input', function () {
  const valor = this.value;
  if (valor === '') {
    strengthBar.style.width = '0%';
    strengthText.textContent = 'La contraseña debe ser segura';
    strengthText.className = 'text-muted small';
    this.setCustomValidity('');
  } else if (!validarFuerzaPassword(valor)) {
    this.setCustomValidity('La contraseña no es lo suficientemente segura');
  } else {
    this.setCustomValidity('');
  }
});

// ========================
// REGISTRO
// ========================
document.getElementById('formRegistro').addEventListener('submit', async (e) => {
  e.preventDefault();

  const password1 = document.getElementById('regPassword').value;
  const password2 = document.getElementById('regPassword2').value;

  if (!validarFuerzaPassword(password1)) {
    mostrarAlerta('danger', 'La contraseña es demasiado débil');
    document.getElementById('formRegistro').classList.add('was-validated');
    return;
  }

  if (password1 !== password2) {
    document.getElementById('regPassword2').setCustomValidity('Las contraseñas no coinciden');
    mostrarAlerta('danger', 'Las contraseñas no coinciden');
    document.getElementById('formRegistro').classList.add('was-validated');
    return;
  } else {
    document.getElementById('regPassword2').setCustomValidity('');
  }

  const email = document.getElementById('regEmail').value;
  const password = password1;
  const rol = document.getElementById('regRol').value;

  try {
    const res = await fetch(`${API}/registro`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password, rol })
    });
    const data = await res.json();

    if (res.ok) {
      mostrarAlerta('success', '¡Registrado con éxito! Iniciando sesión...');
      setTimeout(() => mostrarLogin(), 1500);
    } else {
      mostrarAlerta('danger', data.error || 'Error al registrar');
    }
  } catch (err) {
    mostrarAlerta('danger', 'Error de conexión');
  }
});

// ========================
// LOGIN – AQUÍ ESTÁ LA MAGIA
// ========================
document.getElementById('formLogin').addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  try {
    const res = await fetch(`${API}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();

    if (res.ok) {
      // Guardar token y rol
      localStorage.setItem('token', data.token);
      localStorage.setItem('rol', data.rol);

      mostrarAlerta('success', `¡Bienvenido, ${data.rol}!`);

      // REDIRECCIÓN SEGÚN ROL
      if (data.rol === 'Administrador') {
        setTimeout(() => window.location.href = "admin-dashboard.html", 1000);
      } else {
        setTimeout(() => window.location.href = "dashboard.html", 1000);
      }
    } else {
      mostrarAlerta('danger', data.error || 'Credenciales inválidas');
    }
  } catch (err) {
    mostrarAlerta('danger', 'Error de conexión al servidor');
  }
});

// ========================
// ALERTAS
// ========================
function mostrarAlerta(tipo, mensaje) {
  const alert = document.getElementById('alert');
  alert.className = `alert alert-${tipo} text-center`;
  alert.textContent = mensaje;
  alert.style.display = 'block';
  setTimeout(() => alert.style.display = 'none', 4000);
}