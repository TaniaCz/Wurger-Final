// dashboard-script.js
const API_BASE = 'http://localhost:8080/api';
const token = localStorage.getItem('token');
const rol = localStorage.getItem('rol') || 'Usuario';

// Verificar sesión
if (!token) {
  alert('Debes iniciar sesión para acceder al dashboard');
  window.location.href = 'index.html';
}

// Mostrar rol en la navbar
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('rolDisplay').textContent = rol.toUpperCase();
});

// Cerrar sesión
function logout() {
  localStorage.clear();
  window.location.href = 'index.html';
}

// Sidebar móvil
document.getElementById('hamburger').addEventListener('click', (e) => {
  e.stopPropagation();
  document.getElementById('sidebar').classList.toggle('active');
  document.body.classList.toggle('sidebar-open');
});

document.body.addEventListener('click', (e) => {
  const sidebar = document.getElementById('sidebar');
  if (sidebar.classList.contains('active') && 
      !sidebar.contains(e.target) && 
      !e.target.closest('.hamburger')) {
    sidebar.classList.remove('active');
    document.body.classList.remove('sidebar-open');
  }
});

// Submenús
document.querySelectorAll('.submenu-toggle').forEach(toggle => {
  toggle.addEventListener('click', (e) => {
    e.preventDefault();
    toggle.parentElement.classList.toggle('active');
  });
});

// CARGAR DATOS REALES DEL BACKEND
async function cargarDashboard() {
  try {
    const response = await fetch(`${API_BASE}/dashboard/general`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error('Error al obtener datos del servidor');
    }

    const data = await response.json();

    // Actualizar estadísticas
    document.getElementById('ventasTotales').textContent = 
      `$${Number(data.ventasTotales || 0).toLocaleString('es-AR')}`;
    document.getElementById('productosVendidos').textContent = 
      Number(data.productosVendidos || 0).toLocaleString('es-AR');
    document.getElementById('clientesActivos').textContent = 
      Number(data.clientesActivos || 0).toLocaleString('es-AR');

    document.getElementById('cambioVentas').textContent = data.cambioVentas || '+0% este mes';
    document.getElementById('cambioProductos').textContent = data.cambioProductos || '+0%';
    document.getElementById('cambioClientes').textContent = data.cambioClientes || '+0%';

    // Pedidos recientes
    const listaPedidos = document.getElementById('pedidosRecientes');
    listaPedidos.innerHTML = '';

    if (data.pedidosRecientes && data.pedidosRecientes.length > 0) {
      data.pedidosRecientes.forEach(pedido => {
        const fecha = new Date(pedido.fecha).toLocaleDateString('es-AR');
        const item = document.createElement('li');
        item.className = 'list-group-item d-flex justify-content-between align-items-center';
        item.innerHTML = `
          <div>
            <strong>Orden #${pedido.id}</strong> - ${pedido.producto || 'Varios ítems'}
            <small class="d-block text-muted">${fecha}</small>
          </div>
          <span class="badge bg-success rounded-pill">$${Number(pedido.total).toFixed(2)}</span>
        `;
        listaPedidos.appendChild(item);
      });
    } else {
      listaPedidos.innerHTML = '<li class="list-group-item text-center text-muted">No hay pedidos recientes</li>';
    }

    // Gráfico de ventas mensuales
    const ctx = document.getElementById('salesChart').getContext('2d');
    
    // Destruir gráfico anterior si existe
    if (window.salesChart instanceof Chart) {
      window.salesChart.destroy();
    }

    window.salesChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: data.ventasMensuales?.map(m => m.mes) || ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun'],
        datasets: [{
          label: 'Ventas',
          data: data.ventasMensuales?.map(m => m.total) || [0, 0, 0, 0, 0, 0],
          backgroundColor: 'rgba(255, 107, 107, 0.7)',
          borderColor: '#ff6b6b',
          borderWidth: 2,
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: { callback: value => '$' + value.toLocaleString() }
          }
        }
      }
    });

  } catch (error) {
    console.error('Error cargando dashboard:', error);
    
    // Mostrar mensaje de error bonito
    document.getElementById('statsContainer').insertAdjacentHTML('afterend', 
      `<div class="col-12 text-center text-danger mt-4 p-3 bg-white rounded shadow">
         No se pudieron cargar los datos del servidor. Intenta recargar la página.
       </div>`
    );
  }
}

// Ejecutar al cargar la página
document.addEventListener('DOMContentLoaded', cargarDashboard);